# SmartAlert - Native Android Hackathon App
Built with **Kotlin** and **Jetpack Compose** (Material 3).

## 🚀 How to Install on Your Android Phone for FREE (No Subscription Required!)
You do **not** need a paid Google Play Console Developer Account ($25/year) to run SmartAlert on your real Android phone.

### Step 1: Enable Developer Options on your Phone (Free)
1. On your Android phone, go to **Settings** > **About Phone**.
2. Tap **Build Number** 7 times until you see "You are now a developer!".
3. Go back to **Settings** > **System** (or **Developer Options**).
4. Turn ON **USB Debugging** (or **Wireless Debugging** if on Android 11+).

### Step 2: Open in Android Studio (Free)
1. Download & install free [Android Studio](https://developer.android.com/studio).
2. Unzip this project folder and select **File** > **Open** in Android Studio.
3. Wait for Gradle Sync to complete (takes ~60 seconds on initial load).

### Step 3: Run Directly on your Phone
1. Connect your phone via USB cable (or pair via QR code in Wireless Debugging).
2. Your phone model will appear in the top device dropdown in Android Studio.
3. Click the green **Run ▶** button (or press Shift + F10).
4. Android Studio compiles the Debug APK and installs it straight onto your phone!

### Step 4: Or Build Standalone Debug APK
```bash
./gradlew assembleDebug
```
Output APK is located at: `app/build/outputs/apk/debug/app-debug.apk`.

---

## ⚡ Android Limitation: Do Not Disturb (DND)
- **No third-party app can bypass DND silently without user permission.**
- **The Required Special User-Granted Permission:**
  - The app requests **Notification Policy Access** (`android.permission.ACCESS_NOTIFICATION_POLICY`).
  - System Settings Intent: `Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)`.
- **Category Alarm Rules:**
  - High-priority alarms use `NotificationCompat.setCategory(NotificationCompat.CATEGORY_ALARM)` and `AudioAttributes.USAGE_ALARM`.
  - In Android's DND settings, if the user allows "Alarms", alarms configured with `USAGE_ALARM` will audibly sound even when DND is active.
