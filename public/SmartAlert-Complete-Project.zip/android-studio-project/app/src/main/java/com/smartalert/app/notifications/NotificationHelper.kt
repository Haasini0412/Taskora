package com.smartalert.app.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationCompat
import com.smartalert.app.MainActivity

class NotificationHelper(private val context: Context) {

    private val notificationManager =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    companion object {
        const val CHANNEL_REMINDERS = "channel_smartalert_reminders"
        const val CHANNEL_GEOFENCE = "channel_smartalert_geofence"
        const val CHANNEL_URGENT_ALARM = "channel_smartalert_urgent_alarm"
    }

    init {
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)

            val alarmAudioAttributes = AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .setUsage(AudioAttributes.USAGE_ALARM)
                .build()

            val reminderChannel = NotificationChannel(
                CHANNEL_REMINDERS,
                "SmartAlert Reminders",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Standard task due date and time alerts"
                enableVibration(true)
            }

            val geofenceChannel = NotificationChannel(
                CHANNEL_GEOFENCE,
                "Location & Store Arrival",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Triggered when you arrive near grocery stores or supermarkets"
                enableVibration(true)
            }

            val urgentAlarmChannel = NotificationChannel(
                CHANNEL_URGENT_ALARM,
                "Urgent Alarms (DND Bypass Candidate)",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Urgent high-priority alarms categorized as ALARM for DND priority filtering"
                setSound(alarmSound, alarmAudioAttributes)
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 500, 200, 500, 200, 500)
                setBypassDnd(true)
            }

            notificationManager.createNotificationChannels(
                listOf(reminderChannel, geofenceChannel, urgentAlarmChannel)
            )
        }
    }

    fun isDndPolicyAccessGranted(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            notificationManager.isNotificationPolicyAccessGranted
        } else {
            true
        }
    }

    fun createDndSettingsIntent(): Intent {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
        } else {
            Intent(Settings.ACTION_SETTINGS)
        }
    }

    fun showTaskReminderNotification(taskId: Long, title: String, notes: String, isUrgent: Boolean) {
        val channelId = if (isUrgent) CHANNEL_URGENT_ALARM else CHANNEL_REMINDERS

        val tapIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("EXTRA_TASK_ID", taskId)
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            taskId.toInt(),
            tapIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("⏰ SmartAlert: $title")
            .setContentText(if (notes.isNotBlank()) notes else "Reminder due right now!")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(if (isUrgent) NotificationCompat.CATEGORY_ALARM else NotificationCompat.CATEGORY_REMINDER)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)

        notificationManager.notify(taskId.toInt(), builder.build())
    }

    fun showGeofenceNotification(taskId: Long, title: String, locationName: String) {
        val tapIntent = Intent(context, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            context,
            (taskId + 9999).toInt(),
            tapIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_GEOFENCE)
            .setSmallIcon(android.R.drawable.ic_dialog_map)
            .setContentTitle("📍 Arrived near $locationName")
            .setContentText("Don't forget: $title")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_EVENT)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)

        notificationManager.notify((taskId + 9999).toInt(), builder.build())
    }
}
