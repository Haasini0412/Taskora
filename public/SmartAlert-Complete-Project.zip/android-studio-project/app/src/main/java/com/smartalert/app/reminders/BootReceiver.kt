package com.smartalert.app.reminders

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.smartalert.app.data.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val scheduler = AlarmScheduler(context)
            val db = AppDatabase.getDatabase(context)
            CoroutineScope(Dispatchers.IO).launch {
                val tasks = db.taskDao().getTasksWithReminders().first()
                for (task in tasks) {
                    scheduler.scheduleTaskAlarm(task)
                }
            }
        }
    }
}
