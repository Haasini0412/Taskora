package com.smartalert.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun SmartAlertMainScreen() {
    var selectedTab by remember { mutableIntStateOf(0) }

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Dashboard, contentDescription = "Dashboard") },
                    label = { Text("Today") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.Place, contentDescription = "Locations") },
                    label = { Text("Geofences") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.Warning, contentDescription = "DND Status") },
                    label = { Text("DND Deep Dive") }
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                    label = { Text("Settings") }
                )
            }
        }
    ) { paddingValues ->
        Box(modifier = Modifier.padding(paddingValues)) {
            when (selectedTab) {
                0 -> {
                    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                        Text(
                            text = "Quick Add",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            item {
                                QuickAddChip(
                                    title = "Groceries",
                                    subtitle = "Whole Foods",
                                    icon = Icons.Default.ShoppingCart,
                                    onClick = { }
                                )
                            }
                            item {
                                QuickAddChip(
                                    title = "Meeting",
                                    subtitle = "DND Alarm",
                                    icon = Icons.Default.DateRange,
                                    onClick = { }
                                )
                            }
                            item {
                                QuickAddChip(
                                    title = "Study",
                                    subtitle = "Focus block",
                                    icon = Icons.Default.Star,
                                    onClick = { }
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        WeeklyProductivityCard(completedCount = 14, pendingCount = 5, rate = 74)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("Today's Tasks & Upcoming Alarms", style = MaterialTheme.typography.titleMedium)
                    }
                }
                1 -> Text("SmartAlert Location Geofences (Supermarket triggers)")
                2 -> Text("Android DND Investigation & Policy Access Guide")
                3 -> Text("Settings & Notification Permissions")
            }
        }
    }
}

@Composable
fun QuickAddChip(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    ElevatedCard(
        onClick = onClick,
        modifier = Modifier.width(130.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.height(6.dp))
            Text(title, style = MaterialTheme.typography.labelMedium)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
        }
    }
}

@Composable
fun WeeklyProductivityCard(completedCount: Int, pendingCount: Int, rate: Int) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Weekly Productivity Trends", style = MaterialTheme.typography.titleSmall)
                Text("Success: $rate%", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium)
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text("Completed ($completedCount) vs Pending ($pendingCount)", style = MaterialTheme.typography.bodySmall)
        }
    }
}
