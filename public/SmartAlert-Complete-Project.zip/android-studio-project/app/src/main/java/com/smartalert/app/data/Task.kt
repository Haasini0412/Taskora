package com.smartalert.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class Priority {
    LOW, MEDIUM, HIGH, URGENT
}

@Entity(tableName = "tasks")
data class Task(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val notes: String = "",
    val category: String = "General",
    val priority: Priority = Priority.MEDIUM,
    val dueDateMillis: Long? = null,
    val reminderTimeMillis: Long? = null,
    val isCompleted: Boolean = false,
    val completedAtMillis: Long? = null,
    val createdAtMillis: Long = System.currentTimeMillis(),

    // Geofencing attributes
    val locationName: String? = null,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val geofenceRadiusMeters: Float? = 150f,
    val geofenceTriggerEnter: Boolean = true,

    // High Priority & DND configuration
    val highPriorityDndAlert: Boolean = false
)
