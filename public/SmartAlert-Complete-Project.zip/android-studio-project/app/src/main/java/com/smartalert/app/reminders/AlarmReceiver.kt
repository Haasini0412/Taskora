package com.smartalert.app.reminders

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.smartalert.app.notifications.NotificationHelper

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val taskId = intent.getLongExtra("EXTRA_TASK_ID", -1L)
        val title = intent.getStringExtra("EXTRA_TASK_TITLE") ?: "SmartAlert Task Reminder"
        val notes = intent.getStringExtra("EXTRA_TASK_NOTES") ?: ""
        val isUrgent = intent.getBooleanExtra("EXTRA_IS_URGENT", false)

        val helper = NotificationHelper(context)
        helper.showTaskReminderNotification(taskId, title, notes, isUrgent)
    }
}
