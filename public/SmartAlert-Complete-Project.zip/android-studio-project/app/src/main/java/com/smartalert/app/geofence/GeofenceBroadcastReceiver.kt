package com.smartalert.app.geofence

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingEvent
import com.smartalert.app.notifications.NotificationHelper

class GeofenceBroadcastReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val geofencingEvent = GeofencingEvent.fromIntent(intent) ?: return
        if (geofencingEvent.hasError()) return

        val transition = geofencingEvent.geofenceTransition
        if (transition == Geofence.GEOFENCE_TRANSITION_ENTER) {
            val triggeringGeofences = geofencingEvent.triggeringGeofences ?: return
            val helper = NotificationHelper(context)

            for (geofence in triggeringGeofences) {
                val requestId = geofence.requestId
                val taskId = requestId.removePrefix("GEOFENCE_").toLongOrNull() ?: 1L
                helper.showGeofenceNotification(
                    taskId = taskId,
                    title = "You have arrived near your reminder location!",
                    locationName = "Target / Supermarket Zone"
                )
            }
        }
    }
}
