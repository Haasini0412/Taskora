package com.smartalert.app

import android.app.Application

class SmartAlertApplication : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
